"""
METAR Parser v2.0 - Comprehensive Test Suite

Tests the parser with all provided sample METARs from UK/Europe and North America.

Author: Ian @ Planet Builders
Version: 2.0.0
"""

from metar_parser import parse_metar, format_metar


# UK and European METAR samples
UK_EUROPEAN_SAMPLES = [
    "EGLC 011420Z AUTO 35005KT 310V040 9999 SCT021 11/07 Q1034",
    "EGLL 021420Z AUTO 35004KT 300V040 9999 SCT024 12/06 Q1035",
    "EGMC 031420Z 33006KT 280V350 9999 FEW016 11/08 Q1034",
    "EGSC 041420Z VRB02KT 9999 FEW020 10/05 Q1034",
    "EGSH 131420Z 28004KT 9999 FEW018 11/08 Q1034",
    "EIKN 141630Z 33004KT 290V010 9999 FEW005 BKN020 12/11 Q1033 NOSIG",
    "EGHC 211650Z 09006KT 9999 FEW008 SCT018 12/10 Q1030",
    "EGVO 221720Z 02005KT 9999 BKN025 09/05 Q1031 TEMPO SCT024 RMK BLU TEMPO WHT",
    "LFRK 231730Z AUTO 02002KT 9999 BKN037 09/07 Q1029 TEMPO 3000 DZRA BKN006",
    "EBCV 141725Z AUTO 02007KT 2100 -DZ BKN031/// BKN060/// 10/06 Q1029 YLO",
    "ENOA 141720Z 25021KT 2000 -RA BR OVC005 10/09 Q1021 W///S5",
    "EGDR 151050Z 06008KT 9999 FEW020 BKN030 11/10 Q1027 TEMPO 8000 HZ SCT009 RMK BLU TEMPO GRN",
    "EGCC 151050Z 19004KT 150V220 1500 BR OVC002 08/08 Q1026 BECMG 6000 NSW BKN006",
    "EGVO 221720Z 02005KT 9999 BKN025 09/05 Q1031 TEMPO SCT024 RMK RED",
]

# North American METAR samples
US_CANADIAN_SAMPLES = [
    "CYHZ 151103Z 34020G28KT 15SM OVC007 02/02 A2942 RMK SC8 SLP969",
    "KABQ 151052Z 02006KT 10SM CLR 02/M03 A3001 RMK AO2 SLP133 T00171028 $",
    "KTPH 151056Z AUTO VRB05G18KT 10SM SCT080 03/M05 A2967 RMK AO2 SLP020 T00331050",
    "MMTC 151045Z 00000KT 8SM SKC 15/06 A3006 RMK RTS",
    "CYPA 151100Z 28008KT 15SM FEW007 BKN014 OVC040 M02/M03 A2980 RMK SF1SC7SC1 SF TR SLP115",
    "KSEA 151053Z 00000KT 10SM -RA FEW031 SCT049 OVC065 06/04 A3004 RMK AO2 RAB48 SLP182 P0000 T00560039",
    "MMMD 151041Z 00000KT 6SM SCT015 BKN070 25/24 A2983 RMK 8/570 HZY",
    "TFFR 151100Z AUTO VRB01KT 9999 FEW025 25/24 Q1010 NOSIG",
    "BGBW 151050Z 00000KT 9999 FEW053 SCT062 BKN100 M06/M13 Q1029 RMK 1SC 4SC 7AS",
    "LBBG 041600Z 12012MPS 090V150 1400 R04/P1500N R22/P1500U +SN BKN022 OVC050 M04/M07 Q1020 NOSIG 8849//91=",
    "KMEM 230853Z AUTO 18014G18KT 10SM CLR 16/M02 A3008 RMK AO2 SLP117 T01561022 TSNO VISNO_LOC $",
    "CYLL 162000Z CCA 20010KT 8SM OVC007 M01/M03 A2964 RMK SC8 SLP071",
    "CYYL 162020Z AUTO 20004KT 5SM -SN OVC009 M02/M03 A2974 RMK SLP096",
    "CYEV 162000Z 26003KT 3SM -SN BR OVC023 M16/M18 A2952 RMK SC8 SLP007",
    "PAWN 161956Z AUTO 06003KT 10SM OVC110 M16/M19 A2961 RMK AO2 SLPNO T11611189 FZRANO",
    "BGTL 161955Z AUTO 09008KT 9999 OVC038 M11/M14 A3049 RMK AO2 SLP309 T11141140 TSNO $",
]


def test_all_samples():
    """Test parser with all provided METAR samples."""
    
    print("=" * 80)
    print("METAR PARSER v2.0 - COMPREHENSIVE TEST SUITE")
    print("=" * 80)
    print()
    
    all_samples = UK_EUROPEAN_SAMPLES + US_CANADIAN_SAMPLES
    total_tests = len(all_samples)
    passed = 0
    failed = 0
    
    print(f"Testing {total_tests} real-world METARs...")
    print()
    
    # Test each METAR
    for i, metar in enumerate(all_samples, 1):
        region = "UK/Europe" if metar in UK_EUROPEAN_SAMPLES else "North America"
        
        print(f"{'=' * 80}")
        print(f"TEST {i}/{total_tests} ({region})")
        print(f"{'=' * 80}")
        print(f"Raw METAR: {metar}")
        print()
        
        try:
            # Parse the METAR
            parsed = parse_metar(metar)
            
            # Check if we got basic fields
            if parsed.get('station_id'):
                print(f"✓ Station: {parsed['station_id']}")
            
            if parsed.get('observation_time'):
                print(f"✓ Time: {parsed['observation_time']}")
            
            if parsed.get('temperature') is not None:
                print(f"✓ Temperature: {parsed['temperature']}°C")
            
            if parsed.get('wind'):
                wind = parsed['wind']
                if parsed.get('wind_calm'):
                    print(f"✓ Wind: Calm")
                elif wind.get('direction') == 'VRB':
                    print(f"✓ Wind: Variable at {wind['speed']} KT")
                else:
                    wind_str = f"✓ Wind: {wind['direction']}° at {wind['speed']} KT"
                    if wind.get('gust'):
                        wind_str += f" (gusts {wind['gust']} KT)"
                    print(wind_str)
            
            if parsed.get('visibility'):
                print(f"✓ Visibility: {parsed['visibility']}")
            
            if parsed.get('cavok'):
                print(f"✓ CAVOK: Yes")
            
            if parsed.get('sky_clear'):
                print(f"✓ Sky: {parsed['sky_clear_type']}")
            
            if parsed.get('clouds'):
                print(f"✓ Clouds: {len(parsed['clouds'])} layer(s)")
            
            if parsed.get('altimeter'):
                alt = parsed['altimeter']
                print(f"✓ Altimeter: {alt['value']} {alt['unit']}")
            
            # Check for v2.0 enhancements
            if parsed.get('report_type'):
                print(f"✓ Report Type: {parsed['report_type']}")
            
            if parsed.get('report_modifier'):
                print(f"✓ Modifier: {parsed['report_modifier']}")
            
            if parsed.get('trend'):
                print(f"✓ Trend: {parsed['trend']['type']}")
            
            if parsed.get('automated_station'):
                print(f"✓ Automated: {parsed['automated_station']}")
            
            if parsed.get('weather_began'):
                print(f"✓ Weather began: {parsed['weather_began']}")
            
            if parsed.get('runway_visual_range'):
                print(f"✓ RVR: {len(parsed['runway_visual_range'])} runway(s)")
            
            if parsed.get('sensor_failures'):
                print(f"✓ Sensor failures: {len(parsed['sensor_failures'])}")
            
            if parsed.get('military_weather_codes'):
                print(f"✓ Military codes: {parsed['military_weather_codes']}")
            
            # Format and display
            print()
            print("Formatted Output:")
            print("-" * 80)
            formatted = format_metar(parsed)
            # Print first 10 lines of formatted output
            lines = formatted.split('\n')
            for line in lines[:10]:
                print(line)
            if len(lines) > 10:
                print(f"... ({len(lines) - 10} more lines)")
            
            print()
            print(f"✓ TEST {i} PASSED")
            passed += 1
            
        except Exception as e:
            print(f"✗ TEST {i} FAILED: {str(e)}")
            failed += 1
        
        print()
    
    # Summary
    print("=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed} ({passed/total_tests*100:.1f}%)")
    print(f"Failed: {failed} ({failed/total_tests*100:.1f}%)")
    print()
    
    if failed == 0:
        print("✓ ALL TESTS PASSED!")
    else:
        print(f"✗ {failed} test(s) failed")
    
    return passed, failed


def test_specific_features():
    """Test specific v2.0 features."""
    
    print()
    print("=" * 80)
    print("v2.0 FEATURE TESTS")
    print("=" * 80)
    print()
    
    features_passed = 0
    features_total = 0
    
    # Test 1: SPECI detection
    print("Feature Test 1: SPECI Report Type")
    features_total += 1
    metar = "SPECI EGLL 021420Z AUTO 35004KT 9999 SCT024 12/06 Q1035"
    parsed = parse_metar(metar)
    if parsed.get('report_type') == 'SPECI':
        print("  ✓ SPECI detected correctly")
        features_passed += 1
    else:
        print("  ✗ SPECI not detected")
    
    # Test 2: CAVOK handling
    print("\nFeature Test 2: CAVOK Handling")
    features_total += 1
    metar = "EGLL 021420Z 35004KT CAVOK 12/06 Q1035"
    parsed = parse_metar(metar)
    if parsed.get('cavok') and 'weather' not in parsed:
        print("  ✓ CAVOK detected and weather suppressed")
        features_passed += 1
    else:
        print("  ✗ CAVOK handling incorrect")
    
    # Test 3: Calm winds
    print("\nFeature Test 3: Calm Winds")
    features_total += 1
    metar = "MMTC 151045Z 00000KT 8SM SKC 15/06 A3006"
    parsed = parse_metar(metar)
    if parsed.get('wind_calm'):
        print("  ✓ Calm wind detected")
        features_passed += 1
    else:
        print("  ✗ Calm wind not detected")
    
    # Test 4: TREND forecast
    print("\nFeature Test 4: TREND Forecast")
    features_total += 1
    metar = "EGLL 021420Z 35004KT 9999 SCT024 12/06 Q1035 NOSIG"
    parsed = parse_metar(metar)
    if parsed.get('trend') and parsed['trend']['type'] == 'NOSIG':
        print("  ✓ NOSIG trend detected")
        features_passed += 1
    else:
        print("  ✗ TREND not detected")
    
    # Test 5: Weather event times
    print("\nFeature Test 5: Weather Event Times")
    features_total += 1
    metar = "KTTN 051853Z 04011KT 1/2SM VCTS SN M02/M02 A3006 RMK TSB40 RAE55"
    parsed = parse_metar(metar)
    if parsed.get('weather_began') and parsed.get('weather_ended'):
        print("  ✓ Weather times detected")
        features_passed += 1
    else:
        print("  ✗ Weather times not detected")
    
    # Test 6: MPS to knots conversion
    print("\nFeature Test 6: MPS to Knots Conversion")
    features_total += 1
    metar = "LBBG 041600Z 12012MPS 1400 +SN M04/M07 Q1020"
    parsed = parse_metar(metar)
    if parsed.get('wind') and parsed['wind']['speed'] == 23:  # 12 MPS ≈ 23 KT
        print("  ✓ MPS converted correctly to knots")
        features_passed += 1
    else:
        print("  ✗ MPS conversion incorrect")
    
    # Test 7: Negative temperatures
    print("\nFeature Test 7: Negative Temperatures")
    features_total += 1
    metar = "CYPA 151100Z 28008KT 15SM M02/M03 A2980"
    parsed = parse_metar(metar)
    if parsed.get('temperature') == -2 and parsed.get('dewpoint') == -3:
        print("  ✓ Negative temps parsed correctly")
        features_passed += 1
    else:
        print("  ✗ Negative temps incorrect")
    
    # Test 8: Variable wind direction
    print("\nFeature Test 8: Variable Wind Direction")
    features_total += 1
    metar = "EGSC 041420Z VRB02KT 9999 FEW020 10/05 Q1034"
    parsed = parse_metar(metar)
    if parsed.get('wind') and parsed['wind']['direction'] == 'VRB':
        print("  ✓ VRB wind detected")
        features_passed += 1
    else:
        print("  ✗ VRB wind not detected")
    
    print()
    print("-" * 80)
    print(f"Feature Tests: {features_passed}/{features_total} passed")
    print()
    
    return features_passed, features_total


if __name__ == "__main__":
    # Run all sample tests
    sample_passed, sample_failed = test_all_samples()
    
    # Run feature tests
    features_passed, features_total = test_specific_features()
    
    # Final summary
    print("=" * 80)
    print("FINAL SUMMARY")
    print("=" * 80)
    print(f"Sample METARs: {sample_passed}/{sample_passed + sample_failed} passed")
    print(f"Feature Tests: {features_passed}/{features_total} passed")
    print()
    
    total_tests = (sample_passed + sample_failed) + features_total
    total_passed = sample_passed + features_passed
    
    print(f"Overall: {total_passed}/{total_tests} tests passed ({total_passed/total_tests*100:.1f}%)")
    print()
    
    if sample_failed == 0 and features_passed == features_total:
        print("✓✓✓ ALL TESTS PASSED - PARSER IS PRODUCTION READY! ✓✓✓")
    else:
        print("Some tests failed - review output above")
    
    print("=" * 80)
