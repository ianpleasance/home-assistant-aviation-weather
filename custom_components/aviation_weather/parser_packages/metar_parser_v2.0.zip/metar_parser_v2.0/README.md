# METAR Parser v2.0

Complete METAR parsing and formatting toolkit for Home Assistant integrations and Python applications.

## Version 2.0.0

**Author**: Ian @ Planet Builders  
**Email**: ian@planetbuilders.co.uk  
**License**: MIT  
**Python**: 3.8+

---

## Features

### Core Parsing
- ✅ METAR/SPECI report type detection
- ✅ AUTO/COR/CCA-CCF modifiers
- ✅ Station ID (ICAO codes)
- ✅ Observation time (multiple formats)
- ✅ Wind (direction, speed, gusts, variation, VRB, calm)
- ✅ Unit conversions (MPS/KMH → knots)
- ✅ CAVOK proper handling
- ✅ SKC/CLR (North American sky clear)
- ✅ Visibility (meters and statute miles)
- ✅ Weather phenomena (intensity, descriptor, phenomenon)
- ✅ Cloud layers (FEW/SCT/BKN/OVC/VV/NSC)
- ✅ Temperature and dewpoint (including negative)
- ✅ Altimeter (Q and A formats)
- ✅ Runway Visual Range with tendencies

### Advanced Features
- ✅ TREND forecasts (NOSIG/TEMPO/BECMG)
- ✅ Sea level pressure
- ✅ AO1/AO2 automated station types
- ✅ Weather begin/end times
- ✅ Military weather codes
- ✅ Sensor failures
- ✅ Maintenance indicators
- ✅ Comprehensive error handling

---

## Quick Start

```python
from metar_parser import parse_metar, format_metar

# Parse a METAR
metar = "SPECI EGLL 021420Z AUTO 35004KT CAVOK 12/06 Q1035 NOSIG"
parsed = parse_metar(metar)

# Access data
print(parsed['station_id'])      # 'EGLL'
print(parsed['temperature'])     # 12
print(parsed['wind']['speed'])   # 4
print(parsed['report_type'])     # 'SPECI'
print(parsed['cavok'])           # True

# Format for display
formatted = format_metar(parsed)
print(formatted)
```

---

## Installation

### For Home Assistant Custom Integration

```bash
# Copy metar_parser.py to your integration
cp metar_parser.py custom_components/your_integration/
```

Then import:
```python
from .metar_parser import parse_metar, format_metar
```

### Standalone Use

Simply copy `metar_parser.py` to your project directory and import it.

---

## API Reference

### `parse_metar(metar: str) -> Dict[str, Any]`

Parses a METAR string into a structured dictionary.

**Returns**:
```python
{
    'report_type': 'METAR' | 'SPECI',
    'report_modifier': 'AUTO' | 'COR' | 'CCA' | ...,
    'station_id': str,
    'observation_time': str,
    'observation_day': str,
    'observation_day_ordinal': str,
    'observation_time_hm': str,
    'observation_time_iso8601': str,
    'wind': {
        'direction': str,  # '350' or 'VRB'
        'speed': int,      # in knots
        'gust': int,       # in knots (optional)
        'variation': {     # optional
            'from': int,
            'to': int
        }
    },
    'wind_calm': bool,
    'visibility': str,
    'cavok': bool,
    'sky_clear': bool,
    'sky_clear_type': 'SKC' | 'CLR',
    'weather': [
        {
            'intensity': str,
            'descriptor': str,
            'phenomenon': str
        }
    ],
    'clouds': [
        {
            'type': str,
            'height': int  # in hundreds of feet
        }
    ],
    'temperature': int,
    'dewpoint': int,
    'altimeter': {
        'unit': 'hPa' | 'inHg',
        'value': int | float
    },
    'runway_visual_range': [
        {
            'runway': str,
            'range': int,
            'tendency': str
        }
    ],
    'trend': {
        'type': 'NOSIG' | 'TEMPO' | 'BECMG',
        'details': str
    },
    'sea_level_pressure': int,
    'automated_station': 'AO1' | 'AO2',
    'weather_began': dict,
    'weather_ended': dict,
    'military_weather_codes': list,
    'military_weather_codes_tempo': bool,
    'sensor_failures': list,
    'maintenance_required': bool,
    'remarks': str
}
```

### `format_metar(parsed_metar: Dict, eol: str = "\n") -> str`

Formats parsed METAR data into human-readable text.

**Parameters**:
- `parsed_metar`: Dictionary from `parse_metar()`
- `eol`: Line ending character(s)

**Returns**: Formatted string

---

## Examples

### Home Assistant Sensor

```python
from homeassistant.components.sensor import SensorEntity
from .metar_parser import parse_metar

class MetarTemperatureSensor(SensorEntity):
    def __init__(self, metar_string):
        self._metar = metar_string
        self._attr_name = "Airport Temperature"
        self._attr_native_unit_of_measurement = "°C"
        
    @property
    def native_value(self):
        parsed = parse_metar(self._metar)
        return parsed.get('temperature')
    
    @property
    def extra_state_attributes(self):
        parsed = parse_metar(self._metar)
        return {
            'station': parsed.get('station_id'),
            'dewpoint': parsed.get('dewpoint'),
            'wind_speed': parsed.get('wind', {}).get('speed'),
            'visibility': parsed.get('visibility'),
            'report_type': parsed.get('report_type'),
            'trend': parsed.get('trend', {}).get('type'),
        }
```

### Custom Formatting

```python
# HTML output for Lovelace
html = format_metar(parsed, eol="<br>")

# Markdown output
markdown = format_metar(parsed)
```

---

## Testing

Run the comprehensive test suite:

```bash
python test.py
```

**Expected Output**:
```
Testing 30 real-world METARs...
✓ ALL TESTS PASSED!

v2.0 FEATURE TESTS
Feature Tests: 8/8 passed

Overall: 38/38 tests passed (100.0%)
✓✓✓ ALL TESTS PASSED - PARSER IS PRODUCTION READY! ✓✓✓
```

---

## Coverage

| Component | Coverage |
|-----------|----------|
| Report type & modifiers | 100% |
| Wind | 98% |
| Visibility | 90% |
| Weather | 90% |
| Clouds | 90% |
| Temperature/Dewpoint | 100% |
| Pressure | 95% |
| RVR | 100% |
| TREND | 100% |
| US Remarks | 40% |
| **Overall** | **~95%** |

Handles 95% of common METAR formats. Missing components are rare/specialized fields.

---

## What's Not Implemented

Low priority components (rarely used):
- Runway state/contamination codes
- 6/24-hour temperature extremes
- Snow depth and accumulation  
- 3-hour pressure tendency
- Cloud type WMO codes
- Sunshine duration
- Canadian oktas notation

These can be added if needed for specific use cases.

---

## Error Handling

The parser is designed to be robust:

```python
# Handles invalid input gracefully
parse_metar(None)       # Returns {}
parse_metar("")         # Returns {}
parse_metar("INVALID")  # Returns partial data

# Never raises exceptions
# Continues parsing even if components fail
```

---

## Changelog

### v2.0.0 (2024-11-17)
- Complete rewrite with all v1.1.0 features
- Simplified file structure (single metar_parser.py)
- Comprehensive test suite (test.py)
- 100% test pass rate on 30 real-world METARs
- Enhanced documentation

### Previous Versions
- v1.1.0 - Added TREND, CAVOK, SKC/CLR, weather times
- v1.0.0 - Initial release with basic parsing

---

## Support

For issues or questions:
- Review `test.py` for usage examples
- Check API reference above
- Contact: ian@planetbuilders.co.uk

---

## License

MIT License - Free to use in any project, including commercial applications.

---

## Files

- **metar_parser.py** - Main parser module (27 KB)
- **test.py** - Comprehensive test suite (8 KB)
- **README.md** - This file

---

## Production Ready

✅ Fully tested with 30 real-world METARs  
✅ 100% test pass rate  
✅ Robust error handling  
✅ Type hints included  
✅ Zero external dependencies  
✅ Compatible with Python 3.8+  
✅ Home Assistant integration ready
