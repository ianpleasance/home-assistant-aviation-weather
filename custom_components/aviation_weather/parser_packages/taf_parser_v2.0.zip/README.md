# TAF Parser v2.0

Complete TAF (Terminal Aerodrome Forecast) parser for aviation weather forecasts.

## Author
Ian @ Planet Builders

## Version
2.0.0

## Files Included

- **taf_parser.py** - Main parser module with `parse_taf()` and `format_taf()` functions
- **test.py** - Comprehensive test suite with 42 real-world TAF examples
- **README.md** - This file

## Quick Start

### Basic Usage

```python
from taf_parser import parse_taf, format_taf

# Parse a TAF
taf = "EGLL 121100Z 1212/1318 35010KT 9999 SCT025"
parsed = parse_taf(taf)

# Get specific data
station = parsed['station_id']  # 'EGLL'
wind_speed = parsed['base_forecast']['wind']['speed']  # 10 knots

# Format for display
formatted = format_taf(parsed)
print(formatted)
```

### Running Tests

```bash
# Quick test (quiet mode)
python test.py

# Verbose output
python test.py --verbose

# Show formatted output for each TAF
python test.py --formatted

# Test specific features only
python test.py --features

# Combined options
python test.py -v -f
```

## Features

### Supported TAF Elements

- **Station ID** - 4-letter ICAO airport code
- **Issue Time** - When the TAF was issued (DDHHMM format)
- **Valid Period** - Start and end times (DDHH format)
- **Wind** - Direction, speed, gusts (all units: KT, MPS, KMH)
- **Wind Shear** - Height, direction, speed at altitude
- **Visibility** - Meters, statute miles, CAVOK, P6SM
- **Weather Phenomena** - All standard codes with intensity and descriptors
- **Cloud Layers** - FEW, SCT, BKN, OVC, VV, NSC, SKC
- **Convective Clouds** - CB (Cumulonimbus), TCU (Towering Cumulus)
- **Temperature Forecast** - TX/TN with times
- **Pressure Forecast** - QNH in inHg

### Change Group Types

- **BASE** - Initial forecast conditions
- **FM** - From time (rapid change)
- **TEMPO** - Temporary conditions (< 1hr, < 50% of period)
- **BECMG** - Becoming (gradual change)
- **PROB30/PROB40** - Probability forecasts
- **PROB30 TEMPO / PROB40 TEMPO** - Combined probability and temporary

### Special Indicators

- **AMD** - Amended forecast
- **COR** - Corrected forecast
- **NIL TAF** - Forecast suspended
- **AUTO** - Automated forecast
- **AMD NOT SKED** - Updates not scheduled

## Return Structure

### parse_taf() Returns

```python
{
    "station_id": str,
    "issue_time": str,
    "valid_from": str,
    "valid_to": str,
    "is_amended": bool,
    "is_corrected": bool,
    "is_nil": bool,
    "is_auto": bool,
    "amd_not_sked": bool,
    "base_forecast": {
        "type": "BASE",
        "wind": {
            "direction": str,  # degrees or "VRB"
            "speed": int,      # knots
            "gust": int        # knots (optional)
        },
        "wind_shear": {       # optional
            "height": int,     # feet AGL
            "direction": str,
            "speed": int,
            "gust": int
        },
        "visibility": str,
        "weather": [          # optional
            {
                "intensity": str,
                "descriptor": str,
                "phenomenon": str
            }
        ],
        "clouds": [
            {
                "type": str,
                "height": int,
                "convective": str  # "CB" or "TCU"
            }
        ]
    },
    "forecast_changes": [     # List of change groups
        # Same structure as base_forecast with additional:
        # "valid_from" and "valid_to" (except FM which only has valid_from)
    ],
    "temperature_forecast": { # optional
        "max_temperature": [
            {"value": int, "time": str}
        ],
        "min_temperature": [
            {"value": int, "time": str}
        ]
    },
    "qnh_forecast": [         # optional
        {"unit": "inHg", "value": float}
    ],
    "remarks": str            # optional
}
```

## Examples

### Example 1: Simple TAF

```python
from taf_parser import parse_taf, format_taf

taf = "EGMC 121355Z 1215/1224 18009KT 9999 FEW045"
parsed = parse_taf(taf)
print(format_taf(parsed))
```

Output:
```
Station: EGMC
Issue Time: 121355Z
Valid Period: 1215 to 1224

BASE FORECAST:
  Wind: 180° at 9 KT
  Visibility: 9999 meters
  Clouds:
    - Few at 4500 feet
```

### Example 2: Complex TAF with Changes

```python
taf = "EGPH 121101Z 1212/1312 21012KT 9999 SCT030 BECMG 1216/1219 04009KT TEMPO 1217/1312 6000 RA BKN010"
parsed = parse_taf(taf)

# Access change groups
for change in parsed['forecast_changes']:
    print(f"{change['type']}: {change['valid_from']} to {change['valid_to']}")
```

### Example 3: Temperature Forecast

```python
taf = "LQTZ 121100Z 1212/1312 VRB02KT CAVOK TX13/1214Z TN01/1305Z"
parsed = parse_taf(taf)

temp_forecast = parsed['temperature_forecast']
max_temp = temp_forecast['max_temperature'][0]
min_temp = temp_forecast['min_temperature'][0]

print(f"Max: {max_temp['value']}°C at {max_temp['time']}Z")
print(f"Min: {min_temp['value']}°C at {min_temp['time']}Z")
```

### Example 4: Wind Shear

```python
taf = "KJFK 121730Z 1218/1324 31008KT P6SM SCT250 WS020/35045KT"
parsed = parse_taf(taf)

ws = parsed['base_forecast']['wind_shear']
print(f"Wind shear at {ws['height']}ft: {ws['direction']}° at {ws['speed']}kt")
```

## Test Coverage

The test suite includes 42 real-world TAFs from:

- **UK** - EGMC, EGPE, EIKY, EGXC, EGHE, EGQL, EGPH, EGPA, EGUL, EIDL
- **Europe** - LFQQ, EHVK, EDDS, LIBN, LIPZ, LQTZ, EEKE, EPLB
- **Nordic** - BIRK, BIKF
- **Russia** - UUDD, UEEE
- **Asia** - RJTT, VOHS, VOBG, WADD
- **Middle East** - OMAA, OMDB, FTTJ
- **Africa** - FACT
- **North America** - KLAS, KSUA, KMIA, KHSV, CYYZ
- **Central America/Caribbean** - MMUN, MMLM, MUHA, MYNN, PTYA
- **Oceania** - YSSY

### Test Statistics

- Total TAFs: 42
- Success Rate: 100%
- Features Tested:
  - Simple base forecasts
  - Multiple change groups (TEMPO, BECMG, PROB, FM)
  - Temperature forecasts (TX/TN)
  - Wind shear (WS)
  - Convective clouds (CB, TCU)
  - Special indicators (AMD NOT SKED, CAVOK, NSW)
  - Various visibility formats
  - Multiple unit systems (KT, MPS, SM)
  - QNH pressure forecasts

## Error Handling

```python
parsed = parse_taf(taf_string)

if 'parse_error' in parsed:
    print(f"Error: {parsed['parse_error']}")
else:
    # Process successfully parsed data
    pass
```

## Home Assistant Integration

```python
"""Example Home Assistant sensor."""
from homeassistant.helpers.entity import Entity
from taf_parser import parse_taf, format_taf

class TAFSensor(Entity):
    def __init__(self, station_id):
        self._station_id = station_id
        self._state = None
        self._attributes = {}
    
    def update(self):
        raw_taf = self.fetch_taf(self._station_id)
        parsed = parse_taf(raw_taf)
        
        if 'parse_error' not in parsed:
            base = parsed['base_forecast']
            wind = base.get('wind', {})
            
            self._state = parsed['station_id']
            self._attributes = {
                'wind_direction': wind.get('direction'),
                'wind_speed': wind.get('speed'),
                'visibility': base.get('visibility'),
                'formatted': format_taf(parsed),
            }
```

## Requirements

- Python 3.6 or higher
- No external dependencies (uses only standard library)

## Weather Phenomenon Codes

### Intensity
- `+` Heavy
- `-` Light
- `VC` In vicinity
- (none) Moderate

### Descriptors
- `MI` Shallow
- `BC` Patches
- `DR` Drifting
- `BL` Blowing
- `SH` Showers
- `TS` Thunderstorm
- `FZ` Freezing

### Phenomena
- `DZ` Drizzle
- `RA` Rain
- `SN` Snow
- `SG` Snow Grains
- `IC` Ice Crystals
- `PL` Ice Pellets
- `GR` Hail
- `GS` Small Hail
- `BR` Mist
- `FG` Fog
- `FU` Smoke
- `VA` Volcanic Ash
- `DU` Dust
- `SA` Sand
- `HZ` Haze
- `SQ` Squall
- `FC` Funnel Cloud
- `SS` Sandstorm
- `DS` Duststorm

## Cloud Types

- `SKC` Sky Clear (0/8)
- `NSC` No Significant Cloud
- `FEW` Few (1-2/8)
- `SCT` Scattered (3-4/8)
- `BKN` Broken (5-7/8)
- `OVC` Overcast (8/8)
- `VV` Vertical Visibility (obscured)

## Unit Conversions

The parser automatically converts:
- MPS (meters/second) to knots: × 1.94384
- KMH (km/hour) to knots: × 0.539957
- Cloud heights: hectofeet to feet (× 100)

## License

Created for Planet Builders
Author: Ian @ Planet Builders

## Version History

### 2.0.0 (Current)
- Restructured into two clean files: taf_parser.py and test.py
- Enhanced test suite with 42 real-world TAFs
- Added feature-specific testing
- Improved documentation

### 1.0.0
- Initial release with full TAF parsing capability
- All change group types supported
- Temperature and pressure forecasts
- Wind shear support
- Special indicators (AMD, COR, NIL, etc.)
