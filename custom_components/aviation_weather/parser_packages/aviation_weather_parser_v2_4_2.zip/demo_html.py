#!/usr/bin/env python3
"""
HTML Output Demo for Aviation Weather Parser v2.4.1

This script demonstrates the HTML output capabilities of both
the METAR and TAF parsers with embedded CSS and emoji.

Author: ianpleasance
Version: 2.4.1
"""

from metar_parser import parse_metar, format_metar
from taf_parser import parse_taf, format_taf

# Sample METAR
print("=" * 80)
print("METAR HTML OUTPUT DEMO")
print("=" * 80)
print()

metar = "EGLL 021420Z AUTO 35004KT 300V040 9999 SCT024 12/06 Q1035"
print(f"Input METAR: {metar}")
print()

parsed_metar = parse_metar(metar)
html_metar = format_metar(parsed_metar, is_html=True)

print("HTML Output:")
print(html_metar)
print()
print()

# Sample TAF - Simple
print("=" * 80)
print("SIMPLE TAF HTML OUTPUT DEMO")
print("=" * 80)
print()

taf_simple = "EGMC 121355Z 1215/1224 18009KT 9999 FEW045"
print(f"Input TAF: {taf_simple}")
print()

parsed_taf_simple = parse_taf(taf_simple)
html_taf_simple = format_taf(parsed_taf_simple, is_html=True)

print("HTML Output:")
print(html_taf_simple)
print()
print()

# Sample TAF - Complex with changes
print("=" * 80)
print("COMPLEX TAF HTML OUTPUT DEMO")
print("=" * 80)
print()

taf_complex = "EGPH 121101Z 1212/1312 21012KT 9999 SCT030 BECMG 1216/1219 04009KT TEMPO 1217/1312 6000 RA BKN010"
print(f"Input TAF: {taf_complex}")
print()

parsed_taf_complex = parse_taf(taf_complex)
html_taf_complex = format_taf(parsed_taf_complex, is_html=True)

print("HTML Output:")
print(html_taf_complex)
print()
print()

# Sample TAF - With temperature
print("=" * 80)
print("TAF WITH TEMPERATURE HTML OUTPUT DEMO")
print("=" * 80)
print()

taf_temp = "LQTZ 121100Z 1212/1312 VRB02KT CAVOK TX13/1214Z TN01/1305Z BECMG 1217/1219 2000 BR"
print(f"Input TAF: {taf_temp}")
print()

parsed_taf_temp = parse_taf(taf_temp)
html_taf_temp = format_taf(parsed_taf_temp, is_html=True)

print("HTML Output:")
print(html_taf_temp)
print()
print()

print("=" * 80)
print("DEMO COMPLETE")
print("=" * 80)
print()
print("To view the HTML in a browser:")
print("1. Save the HTML output to a file: demo.html")
print("2. Open in any web browser")
print()
print("Or integrate directly into web applications:")
print("- Flask/Django templates")
print("- Home Assistant custom cards")
print("- React/Vue components (with dangerouslySetInnerHTML/v-html)")
