# Aviation Weather Parser v2.4.2

Complete METAR and TAF parsers with HTML output support for aviation weather data.

## Author
ianpleasance

## Version
2.4.2

## What's New in v2.4.2

### Bug Fixes and Improvements
- **Human-Readable Time Formatting**: TAF valid periods and change group times now display in readable format (e.g., "1500 on 26th to 2400 on 26th" instead of "2615 to 2624")
- **PROB TEMPO Parsing**: Fixed issue where PROB30/PROB40 TEMPO groups would show "N/A" for valid times
- **Station ID Parsing**: Now correctly handles TAFs with "TAF", "TAF AMD", or "TAF COR" prefixes
- **Weather Parsing**: Fixed false positive weather detection (e.g., "GS" was incorrectly detected in cloud layers like "SCT030")
- **Duplicate Group Prevention**: Eliminated duplicate TEMPO entries when PROB TEMPO combinations are present

## What's New in v2.4.1

### Code Improvements
- **HTML Entity Encoding**: All emoji characters have been replaced with HTML entity codes (e.g., `&#127786;&#65039;` instead of `🌪️`)
- Improved compatibility with systems and editors that don't fully support Unicode emoji
- Better portability across different character encoding scenarios
- No functional changes - all features work exactly as before

## What's New in v2.4

### HTML Output Support
- Both `format_metar()` and `format_taf()` now support HTML output with `is_html=True`
- Embedded CSS styling - no external stylesheets needed
- Weather-appropriate emoji for enhanced visual presentation
- Context-sensitive emoji (wind speed, weather phenomena, cloud types)
- Professional styling with clean typography

### HTML Features
- **Labels** in bold with distinct colors
- **Section headers** with underline borders
- **Weather emoji** that adapt to conditions:
  - Wind: 🌬️ (light) → 💨 (moderate) → 🌪️ (strong/gusty)
  - Rain: 🌧️ → 🌦️ (showers/light) → ⛈️ (thunderstorms)
  - Snow: ❄️ (light) → 🌨️ (heavy)
  - Clouds: ☀️ (clear) → ⛅ (few/scattered) → ☁️ (broken/overcast)
  - And many more!
- **Indented change groups** with left borders
- **Responsive design** using system fonts

## Files Included

- **taf_parser.py** - TAF parser with `parse_taf()` and `format_taf()` functions
- **metar_parser.py** - METAR parser with `parse_metar()` and `format_metar()` functions  
- **test.py** - Comprehensive test suite with 42 real-world TAF examples
- **README.md** - This file

## Quick Start

### METAR Usage

```python
from metar_parser import parse_metar, format_metar

# Parse a METAR
metar = "EGLL 021420Z AUTO 35004KT 300V040 9999 SCT024 12/06 Q1035"
parsed = parse_metar(metar)

# Get text format
text = format_metar(parsed)
print(text)

# Get HTML format with emoji
html = format_metar(parsed, is_html=True)
# Returns: <div class="metar-report">...</div> with embedded CSS
```

### TAF Usage

```python
from taf_parser import parse_taf, format_taf

# Parse a TAF
taf = "EGLL 121100Z 1212/1318 35010KT 9999 SCT025"
parsed = parse_taf(taf)

# Get text format
text = format_taf(parsed)
print(text)

# Get HTML format with emoji
html = format_taf(parsed, is_html=True)
# Returns: <div class="taf-report">...</div> with embedded CSS
```

### HTML Output Examples

#### METAR HTML Output
```html
<div class="metar-report">
<style>/* embedded CSS */</style>
  <p><span class="label">Station:</span> EGLL</p>
  <p><span class="label">Wind:</span> 🌬️ 350° at 4 KT</p>
  <p><span class="label">Visibility:</span> 👁️ 9999 meters</p>
  <p><span class="label">Clouds:</span></p>
  <ul>
    <li>⛅ Scattered at 2400 feet</li>
  </ul>
  <p><span class="label">Temperature/Dewpoint:</span> 🌡️ 12/6 °C</p>
</div>
```

#### TAF HTML Output
```html
<div class="taf-report">
<style>/* embedded CSS */</style>
  <p><span class="label">Station:</span> EGLL</p>
  <p><span class="label">Valid Period:</span> 📅 1212 to 1318</p>
  <h3 class="forecast-section">🌤️ <span class="section-title">BASE FORECAST</span></h3>
  <div class="forecast-content">
    <p><span class="label">Wind:</span> 🌬️ 350° at 10 KT</p>
    <p><span class="label">Visibility:</span> 👁️ 9999 meters</p>
  </div>
</div>
```

## Features

### METAR Support
- Station ID
- Observation time (multiple formats)
- Wind (direction, speed, gusts, variation)
- Visibility (meters, statute miles, CAVOK)
- Weather phenomena (all standard codes)
- Cloud layers (all types)
- Temperature and dewpoint
- Altimeter (hPa or inHg)
- Remarks

### TAF Support
- Station ID and issue time
- Valid period
- Base forecast
- All change group types (FM, TEMPO, BECMG, PROB30/40)
- Wind shear at altitude
- Temperature forecasts (TX/TN)
- QNH pressure forecasts
- Special indicators (AMD, COR, NIL, AUTO, AMD NOT SKED)

### Emoji Mapping

**General:**
- ⏰ Time
- 📅 Date/Period
- 🌡️ Temperature
- 🔽 Pressure
- 👁️ Visibility
- ☀️ Clear/CAVOK

**Wind:**
- 🌬️ Light breeze (0-10 KT)
- 💨 Moderate to strong wind (11-30 KT)
- 🌪️ Very strong/gusty wind (>30 KT or gusts >25 KT)

**Weather:**
- 🌧️ Rain
- 🌦️ Light rain or showers
- ⛈️ Thunderstorm
- 🌨️ Snow
- ❄️ Light snow or freezing
- 🌫️ Fog/Mist/Haze
- 🏜️ Dust/Sand

**Clouds:**
- ☀️ Sky clear
- ⛅ Few/Scattered clouds
- ☁️ Broken/Overcast
- ⛈️ Cumulonimbus
- 🌩️ Towering Cumulus

**TAF Sections:**
- 🌤️ Base Forecast
- 🔄 Forecast Changes
- ⏱️ Temporary
- 📈 Becoming
- 🎲 Probability
- ⏩ From (FM groups)
- 🔺 Wind Shear
- ⚠️ Amended/Corrected

## Running Tests

```bash
# Quick test (quiet mode)
python test.py

# Verbose output
python test.py --verbose

# Show formatted output for each TAF
python test.py --formatted

# Test specific features only
python test.py --features
```

## HTML Integration

### Home Assistant

```python
"""Example Home Assistant sensor with HTML output."""
from homeassistant.helpers.entity import Entity
from taf_parser import parse_taf, format_taf

class TAFSensor(Entity):
    def update(self):
        raw_taf = self.fetch_taf(self._station_id)
        parsed = parse_taf(raw_taf)
        
        # For display in frontend
        self._attributes = {
            'formatted_html': format_taf(parsed, is_html=True),
            'formatted_text': format_taf(parsed),
        }
```

### Web Applications

The HTML output includes embedded CSS and works anywhere you can insert HTML:

```python
# Flask example
@app.route('/weather/<station>')
def weather(station):
    taf = fetch_taf(station)
    parsed = parse_taf(taf)
    html = format_taf(parsed, is_html=True)
    return render_template('weather.html', taf_html=html)
```

```html
<!-- weather.html -->
<div class="weather-display">
    {{ taf_html | safe }}
</div>
```

## CSS Customization

The embedded CSS uses class names that you can override:

**METAR classes:**
- `.metar-report` - Container
- `.metar-report .label` - Field labels

**TAF classes:**
- `.taf-report` - Container
- `.taf-report .label` - Field labels
- `.taf-report .forecast-section` - Section headers
- `.taf-report .section-title` - Section title text
- `.taf-report .change-group` - Change group headers
- `.taf-report .change-type` - Change type text
- `.taf-report .forecast-content` - Forecast content container
- `.taf-report .change-content` - Change group content

## Error Handling

Both parsers return a dictionary. Check for parse errors:

```python
parsed = parse_taf(taf_string)

if 'parse_error' in parsed:
    print(f"Error: {parsed['parse_error']}")
else:
    # Process successfully parsed data
    html = format_taf(parsed, is_html=True)
```

## Requirements

- Python 3.6 or higher
- No external dependencies (uses only standard library)

## Test Coverage

- **42 real-world TAFs** from airports worldwide
- **100% success rate** on all test cases
- Coverage includes:
  - Simple and complex forecast groups
  - Temperature forecasts
  - Wind shear
  - Convective clouds (CB, TCU)
  - Special indicators
  - Various visibility formats
  - Multiple unit systems

## Version History

### 2.4.0 (Current)
- Added HTML output support with `is_html=True` parameter
- Embedded CSS styling - no external files needed
- Context-sensitive weather emoji
- Professional typography and layout
- Updated author to ianpleasance

### 2.0.0
- Restructured into clean two-file package
- Enhanced test suite with 42 real-world TAFs
- Improved documentation

### 1.0.0
- Initial release with full TAF parsing capability

## License

Created by ianpleasance

## Support

For issues or questions, contact: ianpleasance
