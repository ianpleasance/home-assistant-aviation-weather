#!/usr/bin/env python3
"""
Test script for TAF parser using real-world TAF data

Author: ianpleasance
Version: 2.4.1
"""

from taf_parser import parse_taf, format_taf
import json


# All 42 TAFs supplied by the user
TEST_TAFS = [
    "EGMC 121355Z 1215/1224 18009KT 9999 FEW045",
    "EGPE 121405Z 1215/1224 36009KT 9999 FEW010 TEMPO 1215/1224 6000 RA BKN010 PROB30 TEMPO 1215/1224 01015G25KT",
    "EIKY 121400Z 1215/1224 07008KT 9999 SCT007 BKN020 TEMPO 1216/1221 4000 RA BKN007 FEW018CB BECMG 1220/1222 VRB03KT TEMPO 1221/1224 4000 -RA BKN010",
    "EGXC 121334Z 1215/1309 19009KT 9999 FEW010 BKN035 TEMPO 1215/1219 BKN018 PROB30 TEMPO 1215/1219 SCT010 TEMPO 1302/1306 4000 -DZ BKN008 PROB30 TEMPO 1303/1305 3000 DZ BKN003 PROB30 TEMPO 1305/1309 SCT005 TEMPO 1306/1309 SCT010",
    "LFQQ 121100Z 1212/1318 17011KT CAVOK",
    "EGHE 121356Z 1215/1218 17018KT 9999 SCT015 TEMPO 1215/1218 5000 RA BR BKN006 PROB40 TEMPO 1215/1218 19020G30KT",
    "EGQL 121340Z 1215/1224 23012KT 9999 FEW018 SCT030 TEMPO 1215/1224 7000 RA -RADZ SCT010 BKN020 PROB30 TEMPO 1215/1216 3000 DZ",
    "EGPH 121101Z 1212/1312 21012KT 9999 SCT030 BECMG 1216/1219 04009KT TEMPO 1217/1312 6000 RA BKN010 PROB30 TEMPO 1219/1224 BKN006 PROB40 TEMPO 1221/1312 05015G26KT PROB30 TEMPO 1300/1312 3000 +RA RADZ BKN008",
    "EHVK 121312Z 1214/1302 18010KT CAVOK",
    "EDDS 121100Z 1212/1312 VRB03KT CAVOK PROB30 TEMPO 1220/1308 3000 BR",
    "LIBN 121400Z 1215/1224 36005KT CAVOK TEMPO 1215/1217 9999 FEW030 BECMG 1219/1221 7000 NSC",
    "LIPZ 121100Z 1212/1318 VRB04KT 6000 NSC BECMG 1300/1302 2000 BR BKN010 TEMPO 1302/1308 0400 FG BKN003 BECMG 1308/1310 7000 NSC",
    "LQTZ 121100Z 1212/1312 VRB02KT CAVOK TX13/1214Z TN01/1305Z BECMG 1217/1219 2000 BR BECMG 1219/1221 0300 FG VV002 BECMG 1308/1310 CAVOK",
    "BIRK 121330Z 1215/1315 08004KT CAVOK TXM00/1309Z TNM04/1222Z",
    "FTTJ 121100Z 1212/1318 06010KT 6000 NSC BECMG 1214/1216 34004KT PROB40 1216/1219 4000 DU PROB30 1302/1306 4000 DU BECMG 1305/1307 06010KT",
    "FACT 121000Z 1212/1318 18013KT CAVOK TX27/1312Z TN17/1304Z FM121500 18010KT 9999 BKN018 FM122300 18012KT CAVOK BECMG 1307/1309 18022KT",
    "OMAA 121100Z 1212/1318 33012KT 8000 NSC BECMG 1216/1218 04005KT BECMG 1309/1311 34011KT BECMG 1316/1318 04005KT",
    "VOHS 121400Z 1215/1224 06006KT 5000 HZ NSC",
    "VOBG 121400Z 1215/1224 06008KT 6000 SCT012 BECMG 1220/1221 3000 BR SCT008",
    "WADD 121100Z 1212/1318 23010KT 5000 TSRA FEW014CB BKN014 BECMG 1220/1222 9999 SCT016",
    "KLAS 121445Z 1215/1318 VRB05KT P6SM SCT150 BKN200 FM121800 07006KT P6SM SCT150 BKN200 FM130200 21006KT P6SM SCT120 BKN150 FM131400 VRB05KT P6SM SCT100 BKN120",
    "KSUA 121120Z 1212/1312 32005KT P6SM FEW035 FEW300 FM121600 04008KT P6SM SCT035 SCT300 FM130000 VRB04KT P6SM SKC AMD NOT SKED",
    "KMIA 121449Z 1215/1318 35007KT P6SM BKN040 BKN250 FM121600 04010KT P6SM BKN040 FM130000 02006KT P6SM SCT040 FM131500 02010KT P6SM FEW040",
    "YSSY 121400Z 1215/1318 34010KT CAVOK FM130300 05017KT CAVOK FM131000 01010KT CAVOK FM131500 23005KT CAVOK",
    "MMUN 121119Z 1212/1312 03005KT P6SM SCT015 SCT080 TX28/1219Z TN22/1312Z FM121800 02010KT 6SM HZ BKN015 BKN080 OVC250 BECMG 1220/1222 6SM -RA BKN015CB OVC080 TEMPO 1222/1302 5SM RA FM130300 06006KT 6SM HZ SCT015 BKN080 FM130900 02004KT P6SM SCT015 SCT080",
    "MMLM 121602Z 1218/1318 26010KT P6SM SCT040 SCT250 FM130600 31005KT P6SM SCT250 FM131700 30010KT P6SM SCT250",
    "MUHA 121100Z 1212/1312 VRB04KT 9000 SCT030 BECMG 1213/1215 06012KT BECMG 1302/1304 VRB04KT",
    "MYNN 121100Z 1212/1312 07012KT 9999 SCT035 BKN065",
    "BIKF 121330Z 1215/1315 04015KT 9999 FEW040 TX02/1315Z TNM05/1300Z BECMG 1221/1223 VRB03KT BECMG 1313/1315 27010KT BKN014 OVC030",
    "CYYZ 121440Z 1215/1318 25012G22KT P6SM SCT015 OVC030 TEMPO 1215/1221 P6SM -SHRA BKN015 OVC030 BECMG 1215/1216 26018G28KT FM122100 26012G22KT P6SM -SHRA OVC025 FM122300 26012KT P6SM -SHRA OVC015 FM130600 28012KT P6SM BKN015 FM131000 28012KT P6SM SCT020 BKN080 FM131400 28012G22KT 6SM -SHRA BR BKN020 BECMG 1314/1316 30015G25KT RMK NXT FCST BY 121800Z",
    "KHSV 121120Z 1212/1312 21010KT P6SM SKC FM121400 25008G16KT P6SM FEW250 FM130000 25002KT P6SM SKC",
    "UUDD 121355Z 1215/1321 08003MPS 6000 OVC005 TX06/1311Z TN04/1218Z TEMPO 1215/1219 3000 -DZ BR OVC003 BECMG 1219/1221 2500 BR OVC003 TEMPO 1221/1308 0400 FG OVC002 FM130900 22005MPS 6000 BKN007 TEMPO 1314/1321 22008G13MPS BKN016",
    "EEKE 121415Z 1215/1224 20015KT 9999 BKN008 TEMPO 1215/1224 20016G32KT TEMPO 1219/1224 3000 RA",
    "EPLB 121130Z 1212/1312 VRB02KT 9999 BKN013 BECMG 1212/1215 SCT020 BECMG 1218/1221 0500 FG BKN001 BECMG 1300/1303 18010KT 6000 BKN005 BECMG 1303/1306 FEW010",
    "EGPA 121405Z 1215/1224 36014KT 9999 SCT015 TEMPO 1215/1218 02018G28KT 8000 -RA BKN010 PROB30 TEMPO 1215/1218 4000 RADZ BKN006 PROB30 TEMPO 1218/1224 8000 SHRA BKN010",
    "OMDB 121100Z 1212/1318 33010KT 8000 NSC BECMG 1216/1218 08005KT BECMG 1308/1310 34010KT BECMG 1316/1318 07005KT",
    "PTYA 121141Z 1212/1312 07010KT P6SM VCSH SCT016 SCT040 BKN120",
    "RJTT 121105Z 1212/1318 16006KT 9999 FEW030 BECMG 1216/1218 35005KT BECMG 1300/1303 08004KT BECMG 1306/1309 35010KT",
    "UEEE 121400Z 1215/1321 29003MPS 9999 SCT030 BKN100 TEMPO 1215/1221 2100 -SN BR SCT007 BKN025 OVC070 TEMPO 1221/1303 0500 SN FZFG VV003",
    "EGUL 121400Z 1214/1320 18010G22KT 9999 VCSH SCT025 BKN100 QNH2961INS BECMG 1216/1217 18010G20KT 9999 NSW SCT030 BKN060 QNH2960INS BECMG 1301/1302 22010G22KT 9999 VCSH BKN030 QNH2958INS TEMPO 1304/1309 8000 -SHRA BKN015 BECMG 1310/1311 23010G20KT 9999 NSW SCT020 BKN100 QNH2960INS TX20/1214Z TN09/1305Z",
    "EGHE 121356Z 1215/1218 17018KT 9999 SCT015 TEMPO 1215/1218 5000 RA BR BKN006 PROB40 TEMPO 1215/1218 19020G30KT",
    "EIDL 121400Z 1215/1224 04014KT 9999 SCT018 BKN030 TEMPO 1216/1224 04018G30KT PROB40 TEMPO 1223/1224 4000 RA BKN012",
]


def run_tests(verbose: bool = False, show_formatted: bool = False):
    """
    Run tests on all supplied TAFs.
    
    Args:
        verbose: If True, print detailed output for each TAF
        show_formatted: If True, show formatted output for each TAF
        
    Returns:
        Dictionary with test results
    """
    results = {
        "total": len(TEST_TAFS),
        "passed": 0,
        "failed": 0,
        "errors": []
    }
    
    print("=" * 80)
    print("TAF PARSER TEST SUITE v2.4.1")
    print("=" * 80)
    print(f"Testing {len(TEST_TAFS)} real-world TAFs...")
    print()
    
    for i, taf in enumerate(TEST_TAFS, 1):
        parsed = parse_taf(taf)
        station = parsed.get('station_id', 'UNKNOWN')
        
        if 'parse_error' in parsed:
            results['failed'] += 1
            error_info = {
                "taf": taf,
                "station": station,
                "error": parsed['parse_error']
            }
            results['errors'].append(error_info)
            
            print(f"✗ TAF {i:2d} ({station}): PARSE ERROR")
            if verbose:
                print(f"   TAF: {taf[:70]}...")
                print(f"   Error: {parsed['parse_error']}")
            print()
        else:
            results['passed'] += 1
            
            if verbose:
                print(f"✓ TAF {i:2d} ({station}): OK")
                print(f"   TAF: {taf[:70]}{'...' if len(taf) > 70 else ''}")
                
                if show_formatted:
                    print()
                    print("   Formatted Output:")
                    print("   " + "-" * 76)
                    formatted = format_taf(parsed)
                    for line in formatted.split('\n'):
                        print(f"   {line}")
                print()
            else:
                print(f"✓ TAF {i:2d} ({station}): OK")
    
    print()
    print("=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Total TAFs tested: {results['total']}")
    print(f"Passed: {results['passed']}")
    print(f"Failed: {results['failed']}")
    
    if results['failed'] > 0:
        print()
        print("ERRORS:")
        for error in results['errors']:
            print(f"  Station {error['station']}: {error['error']}")
    else:
        print()
        print("*** All TAFs parsed successfully!")
    
    return results


def test_specific_features():
    """Test specific TAF features with targeted examples."""
    print()
    print("=" * 80)
    print("TESTING SPECIFIC FEATURES")
    print("=" * 80)
    print()
    
    test_cases = [
        {
            "name": "Wind Shear",
            "taf": "KJFK 121730Z 1218/1324 31008KT P6SM SCT250 WS020/35045KT",
            "check": lambda p: p.get('base_forecast', {}).get('wind_shear') is not None
        },
        {
            "name": "Temperature Forecast",
            "taf": "LQTZ 121100Z 1212/1312 VRB02KT CAVOK TX13/1214Z TN01/1305Z",
            "check": lambda p: 'temperature_forecast' in p
        },
        {
            "name": "AMD NOT SKED",
            "taf": "KSUA 121120Z 1212/1312 32005KT P6SM SKC AMD NOT SKED",
            "check": lambda p: p.get('amd_not_sked', False)
        },
        {
            "name": "Multiple FM Groups",
            "taf": "KLAS 121445Z 1215/1318 VRB05KT P6SM SCT150 FM121800 07006KT P6SM SCT150 FM130200 21006KT P6SM SCT120",
            "check": lambda p: len(p.get('forecast_changes', [])) >= 2
        },
        {
            "name": "PROB TEMPO Combination",
            "taf": "EGPE 121405Z 1215/1224 36009KT 9999 FEW010 PROB30 TEMPO 1215/1224 01015G25KT",
            "check": lambda p: any(c.get('type') == 'PROB30 TEMPO' for c in p.get('forecast_changes', []))
        },
        {
            "name": "Convective Clouds (CB)",
            "taf": "EIKY 121400Z 1215/1224 07008KT 9999 SCT007 BKN020 TEMPO 1216/1221 4000 RA BKN007 FEW018CB",
            "check": lambda p: any(
                any(c.get('convective') == 'CB' for c in change.get('clouds', []))
                for change in p.get('forecast_changes', [])
            )
        },
    ]
    
    for test in test_cases:
        parsed = parse_taf(test['taf'])
        passed = test['check'](parsed)
        status = "✓" if passed else "✗"
        print(f"{status} {test['name']}")
        if not passed:
            print(f"   TAF: {test['taf']}")
            print(f"   Parsed: {json.dumps(parsed, indent=2)}")
        print()


if __name__ == "__main__":
    import sys
    
    # Parse command-line arguments
    verbose = "--verbose" in sys.argv or "-v" in sys.argv
    show_formatted = "--formatted" in sys.argv or "-f" in sys.argv
    features_only = "--features" in sys.argv
    
    if len(sys.argv) == 1 or "--help" in sys.argv or "-h" in sys.argv:
        print("TAF Parser Test Suite v2.4.1")
        print()
        print("Usage:")
        print("  python test.py                 # Run all tests (quiet mode)")
        print("  python test.py --verbose       # Run all tests with details")
        print("  python test.py --formatted     # Show formatted output for each TAF")
        print("  python test.py --features      # Test specific features only")
        print("  python test.py -v -f           # Verbose with formatted output")
        print()
        sys.exit(0)
    
    if features_only:
        test_specific_features()
    else:
        results = run_tests(verbose=verbose, show_formatted=show_formatted)
        
        # Test specific features as well
        if verbose:
            test_specific_features()
        
        # Exit with error code if any tests failed
        sys.exit(0 if results['failed'] == 0 else 1)
